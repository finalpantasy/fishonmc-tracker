# Rustic Fantasy Armor - Field Canvas Complete

Armor-only companion layer for FishOnMC. It contains exactly 11 inventory textures and 6 worn surfaces for the shared dyeable-leather and chainmail armor routes. The art uses weathered olive field canvas, brown leather reinforcement, stitched seams, iron buckles, and chainmail. Server dye and enchantment glint remain active.

Enable this pack above the official FishOnMC server pack. The hidden ServerPackOverlay marker in the description keeps it above downloaded server resources. It contains no GUI/HUD, food, fish, rods, item models, fonts, sounds, locations, furniture, or unrelated cosmetics.