# Rustic Fantasy 128 - Items and Gear Icons Only

Optional companion to the Fish Only pack. Includes 304 original 128px inventory icons. Equipped fishing rods intentionally remain the official FishOnMC models supplied by the server pack.

This pack deliberately excludes model JSON, custom 3D rods, rod-material atlases, fish, HUD, GUI, armor, locations, sounds, and unrelated cosmetics. It can be installed alone or above the server pack beside Fish Only. ServerPackOverlay is required on multiplayer so the marked local icon overrides remain above server resources.

Unofficial community project. Not affiliated with FishOnMC or Mojang.