# Font source

This pack uses **Atkinson Hyperlegible Next Regular**, designed for clear character recognition and licensed under the SIL Open Font License 1.1.

- Project: https://github.com/googlefonts/atkinson-hyperlegible-next
- Source revision: `7925f50f649b3813257faf2f4c0b381011f434f1`
- Font file: `fonts/ttf/AtkinsonHyperlegibleNext-Regular.ttf`
- Local font SHA-256: `88ED5C31A71584C7772963B02D04BEF1EB7E3D2E9C8B9CB204339B1F82CF432C`

The four font definitions intentionally contain only the TrueType provider. Minecraft merges font-provider stacks from enabled resource packs, allowing FishOn Extras key glyphs and FishOn HUD graphics to remain available as fallbacks.
